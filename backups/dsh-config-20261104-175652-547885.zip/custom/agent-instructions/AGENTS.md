# 全局语言规范（适用于本机所有会话、所有输出）

## 语言政策

> ⚠️ **本机所有输出一律以中文为主，不限于「对话交流」。**
> 适用范围包含但不限于：思考与推理过程、回复正文、工具调用的 description、
> 待办与计划、总结与复盘、脚本注释、生成的文档、旁白、标题、表格、清单、
> 进度说明、报错解释、提问、确认请求。

- **思考也用中文**：推理、内部分析、决策说明不得默认用英文，一律中文表达。
- **工具 description 用中文**：调用工具时的说明文字一律中文
  （如「读取设备属性归档」「验证归档文件完整性」），不写英文短语。
- 仅以下内容保留原语言，**不做翻译**：
  - 代码本体、命令、报错原文、日志输出、文件路径、配置键名、专有名词；
  - 已有行业惯例的技术术语（如 API、Git、Jetpack Compose），可在中文语境中直接使用。
- 用户用中文提问时，必须用中文回答；用户用其他语言提问时，仍**优先用中文回复**，
  必要时附上原文关键句。
- 面向用户的标题、表格、清单、进度说明等**均使用中文**。
- 例外：当某项内容的受众是机器或外部系统（JSON 键名、API 字段、第三方接口约定）
  时，保持其原样，不强行汉化。

# 本机环境（必读）

> 详细档案见 `~/.dsh/DEVICE.md`（硬件/root/LSPosed/模块）与 `~/.dsh/ACCOUNT.md`（账号凭证）。
> 动手前先读，不要凭记忆操作本机。

## 环境要点

- 宿主：Xiaomi 2608BPX34C，Android 17（SDK 37），XRing 玄戒 **O3**（`xring_o3_asic`），内核 6.18.21-android17。
- Root 方案：**KernelSU 3.3.1**（SELinux `u:r:ksu:s0`）。特权通道 `dsh-native shell --reason <理由> -- <命令>`，uid 0。
- 每次 `dsh-native` 调用**必须带 `--reason`**，否则直接报错拒绝执行。
- 框架：LSPosed v2.2.1 (7912)，Xposed API **102**，依赖 Zygisk（`zygisksu`）。
- 存储：`/sdcard` = `/root/workspace/sdcard`，951G，已用 49%。
  共享存储**不支持硬链接/软链接/可执行位**：`write` 工具在该路径会 EINVAL，
  改用 `edit` 工具或 shell 重定向（`cat > file` / `printf … > file`）。
- 屏蔽目录（读到空是正常的，不要重试）：`DCIM`、`Pictures`、`Movies`、`Android/media`。
- 内存偏紧（15G 总，可用约 3.2G，swap 已用 6.8G）。重负载前先 `free -h`。

## 🔴🔴 重启纪律：任何重启，都必须先经过用户同意

> **用户 2026-10-18 明确要求：**
> **「所有的重启，不管软重启还是硬重启，只要是重启，你就需要经过我的同意。」**

### 铁律

**任何形式的「重启」，在执行前一律必须先取得用户明确同意。无例外。**

包括但不限于：

| 类型 | 具体动作 |
|---|---|
| 硬重启 | `reboot`、`svc power reboot`、`reboot recovery`、`reboot bootloader`、`reboot -p`（关机） |
| 系统级重启 | `stop && start`、重启 zygote（`setprop ctl.restart zygote`） |
| **软重启** | `ksud soft-reboot`、KSU 主界面右上角软重启、`yhyc` 相关重载 |
| 框架/服务重启 | 重启 SystemUI（`killall com.android.systemui`）、重启 LSPosed 相关服务 |
| **App 进程重启** | `am force-stop <pkg>`、`kill -9 <pid>`、重启目标作用域 App |

> ⚠️ **注意：这一条比之前的规则更严。**
> 此前文件写的是「软重启允许且鼓励优先使用」——**该表述已作废**。
> 现在**软重启同样需要用户同意**，不再有任何「默认可执行」的重启动作。

### ✅ 例外：重启 SystemUI 已获长期授权（2026-10-20 用户明确要求）

> **用户原话：「重启 System UI不需要我同意，写进记忆里面」**

**`killall com.android.systemui` 属于已授权动作，不必每次询问，直接执行。**

- 适用范围：**仅** SystemUI 进程（`com.android.systemui`）
- 目的：让 LSPosed 重新注入模块（SystemUI 重启后有时不会自动重新注入）
- 其他任何重启（软重启、硬重启、zygote、其他 App 进程）**仍然需要事先征得同意**

```bash
# 已授权，可直接执行
dsh-native shell --reason "重启SystemUI让LSPosed重新注入模块" -- "killall com.android.systemui"
```

### 正确姿势

```text
需要重启时：
  1. 停下来（不要执行）
  2. 告诉用户：为什么要重启、重启什么、影响范围、大概耗时
  3. 等用户明确同意
  4. 同意后才执行
```

**不允许**以「这是软重启」「只有 3 秒」「文档这么写」「不重启就不生效」为理由跳过确认。

### 优先级顺序（仅在获得同意后，用于选择最小代价的方式）

用户同意后，仍应**选择影响最小的方式**，从轻到重：

1. 模块自带脚本：`sh /data/adb/modules/<模块>/action.sh`
2. SystemUI 级：`killall com.android.systemui`
3. zygote 级：`setprop ctl.restart zygote`（重载 Zygisk / LSPosed）
4. KSU 软重启：`/data/adb/ksu/bin/ksud soft-reboot`
5. `reboot`（最后手段）

> 📌 另：**优先选择「不需要重启」的方案**。
> 依据「⚡ LSPosed 调试的根本原理」，多数模块更新**只需重启目标 App**
> —— 但那**同样属于重启**，**同样需要用户同意**。

### ⚠️ 软重启必须「两步走」（KSU / LSPosed 开发保底动作）

> 完整流程、故障对因、数据库改法见 **[`KSU-LSPOSED-RECOVERY.md`](KSU-LSPOSED-RECOVERY.md)**，动手前必读。

**KSU 里月虹模块的「刷新模块」+「重载模块」跑完之后，间隔 10 秒，再执行 KSU 的软重启。**
顺序不可颠倒，间隔不可省。

```bash
# Step 1（必做）：月虹「刷新模块 / 重载模块」
cd /data/adb/modules/YH_YC && ./yhyc --reload     # 等到「主进程已重新运行」
# 间隔 10 秒（必做，不可省）
sleep 10
# Step 2（必做）：KSU 软重启（= KSU 主界面右上角那个）
/data/adb/ksu/bin/ksud soft-reboot
```

省略 Step 1 或不留间隔 ⇒ 装好的模块会被漏扫，甚至从安装列表消失。
**不要**用 `xposed_guard/action.sh`（那是 Vector 式，会真正重启 zygote、黑屏 20–40 秒）。

### 🔴 软重启只在「模块首次加载」时需要 —— 后续更新只需重启作用域 App

**这条是省事的大前提，别每次都软重启。**

| 情形 | 正确动作 |
|---|---|
| **模块首次安装 / 首次被 LSPosed 加载** | 月虹刷新 → 间隔10秒 → KSU 软重启（**一次性**） |
| **模块已被正常加载，之后更新了 APK** | ⚠️ **按 2026-10-28 定稿方案：`pm install -r` → 同步 `apk_path` → 重启 SystemUI**（见下方「🥇 现行唯一方案」）。`cp` 覆盖会命中 lspd 的 dex 缓存，**无效** |
| 作用域 App 是系统进程（如 `com.android.systemui`） | 重启那个进程：`killall com.android.systemui` |
| 作用域 App 是普通应用（如小鹏 App） | `am force-stop <pkg>` 后重新启动它 |

原理：LSPosed 在**进程启动时**注入模块，用 ClassLoader **直接读 APK 文件**。
所以只要那个进程重启一次，就会读到新代码 —— 不需要 `pm install`、不需要重装 zygote、不需要软重启。
（详细论证见下方「⚡ LSPosed 调试的根本原理」）

**判断模块是否已被加载**：`lspctl status` 的 `Modules: N installed` 里能看到它，
或 logcat / LSPosed verbose log 里出现该模块的 tag。

### ⚡ LSPosed 调试的根本原理（用户亲述，2026-10-16）—— 方案测试必须按此执行

> **LSPosed 是通过 ClassLoader 直接读 APK 文件的。只要文件内容变了，
> 目标进程下次启动就读到新代码 —— 不需要 `pm` 重新登记。**
> **因此 LSP 可以在现成安装的模块上直接调试，不用重新安装模块。**
> 🔴 **但注意：2026-10-28 已定稿 —— lspd 启动后会把模块 dex 缓存起来，
> 「只改文件内容」不生效，必须走「🥇 现行唯一方案」。本节仅作原理背景保留。**

**这是本机调试模块的最短路径，省掉中间所有环节：**

| 步骤 | 动作 | 是否需要 |
|---|---|---|
| 1 | 直接修改模块 APK 文件内容（或替换该文件） | ✅ 必须 |
| 2 | `pm install` 重新登记 | ❌ **不需要** |
| 3 | 重启 zygote / 软重启 / 重启手机 | ❌ **不需要** |
| 4 | **重启目标作用域 App**（让 ClassLoader 重读文件） | ✅ **唯一需要的动作** |

**为什么可行（本机实测依据）**：
- `modules_config.db` 里存的是模块 APK 的**路径引用**（`apk_path`），**不是 APK 内容的副本**；
  文件内容变了，路径指向的就是新内容。
- LSPosed 用 **ClassLoader 直接加载 APK 文件**，不做内容校验、不缓存旧字节码。
- 模块注入发生在**目标进程启动时**，所以「重读文件」的触发点就是**目标进程重启**。

**实操**：
```bash
# 1. 直接改 APK 文件内容（或推送新 APK 到同一路径）
# 2. 重启目标作用域 App —— 唯一必需的动作
am force-stop <目标包名>            # 普通应用
killall com.android.systemui        # 系统进程（如 SystemUI）
# 完成。进程下次启动即加载新代码。
```

**判断是否生效**：`lspctl status` → `Modules: N installed`；或 logcat 里看该模块 tag。

> ⚠️ 本机实测：`LSPosed 2.2.1 (7912)`、`API: 102`、`Modules: 19 installed, 18 enabled`、
> `System server: connected`。
> **方案测试时按此原理执行**——不要每次改代码都去 `pm install` + 软重启，
> 那是多余的中间环节，浪费时间和资源。

### 🔴 模块「激活状态」与「更新生效」的完整规则（用户亲述，2026-10-16）

**这是省事的核心，务必遵守：**

| 场景 | 正确动作 | 要不要重启手机/zygote |
|---|---|---|
| **模块已被 LSPosed 激活**，只是改了 APK 文件内容 | 直接改文件 → **重启该作用域 App**（`pm install` 非必需） | ❌ **不要** |
| 作用域 App 是普通应用（如小鹏 App） | `am force-stop <pkg>` 后重新启动它 | ❌ |
| 作用域 App 是系统进程（如 SystemUI） | `killall com.android.systemui` | ❌ |
| **卸载后重装**模块 | ⚠️ 模块在 LSPosed 里会**变成未激活**，**需要手动激活** | 视激活方式而定 |
| 模块**首次**被 LSPosed 发现 | 需要 zygote 重载一次（一次性） | ✅ 仅此一次 |

**关键原理**：LSPosed 在**目标进程启动时**注入模块，用 ClassLoader **直接读 APK 文件**。
所以「模块代码更新」只需要**目标进程重启**，与手机重启、zygote、软重启都无关，
**也无需 `pm install` 重新登记**（见上方「⚡ LSPosed 调试的根本原理」）。

**踩过的坑（重要）**：
1. ❌ 每次改代码都去软重启 → **完全没必要**，重启作用域 App 就够
2. ❌ 卸载重装后以为会自动激活 → **不会**，必须手动激活
3. ❌ 覆盖安装后 LSPosed 可能仍加载旧版 → 因为 `modules.apk_path` 缓存失效
   → **解法见下方「🎯 DEX 启用方案」**

### 🥇【现行唯一方案】模块更新后跑旧代码 → `pm install -r` + 同步 apk_path + 重启 SystemUI

> **用户 2026-10-28 明确定稿并要求记住：**
> **「LSPosed 只认 `modules_config.db` 里的 `apk_path`，而且 lspd 启动后会把模块 dex 缓存起来。
> 所以 `cp` 覆盖 `base.apk` 后，无论怎么重启 SystemUI 都不会生效。
> 正确做法是：用 `pm install -r` 更换 codePath → 同步数据库 `apk_path` → 再重启 SystemUI。」**
>
> **触发条件：LSP 插件覆盖更新异常（改了代码但跑的还是旧代码）时，直接用这套方案。**

#### 为什么 `cp` 覆盖会失效（根因，两条缺一不可）

| 机制 | 后果 |
|---|---|
| LSPosed 只认 `modules_config.db` 的 `apk_path` | 路径对不上 = 根本找不到模块 |
| **lspd 启动后把模块 dex 缓存起来** | **路径相同但内容变了 → 仍用旧 DEX** |

第 2 条是关键：`cp` 覆盖**不换路径**，dex 缓存自然命中 → 新版代码永远上不去。
所以下面「重启作用域 App 即可」的旧说法**在缓存机制面前不成立**。

#### ✅ 三步标准流程（顺序不可颠倒）

```bash
# ① 用 pm install -r 安装新包 —— 目的就是让它换一个新的 codePath
dsh-native shell --reason "用pm install -r覆盖安装模块以更换codePath" -- \
  "pm install -r /sdcard/Documents/DSH/builds/<项目>/<新版本>.apk"

# ② 查出新路径，同步写进 modules_config.db 的 apk_path
dsh-native shell --reason "查询模块新的APK真实路径" -- \
  "pm path <模块包名>"          # 输出 package:/data/app/~~xxx/base.apk
dsh-native shell --reason "同步LSPosed数据库中的模块apk_path到新路径" -- \
  "cd /data/adb/lspd/config && cp -f modules_config.db modules_config.db.bak && \
   python3 - <<'EOF'
import sqlite3
db='/data/adb/lspd/config/modules_config.db'
new='/data/app/~~新hash==/<模块包名>-新hash==/base.apk'
c=sqlite3.connect(db)
c.execute(\"UPDATE modules SET apk_path=? WHERE module_pkg_name=?\", (new,'<模块包名>'))
c.commit(); c.close()
EOF
   chmod 600 modules_config.db"

# ③ 重启 SystemUI（已获长期授权，无需再问）
dsh-native shell --reason "重启SystemUI让LSPosed重新注入模块" -- "killall com.android.systemui"
```

#### 硬性纪律（与既有铁律一致，不得违反）

1. **全程不停 lspd** —— 不 `lspctl stop`、不 `kill lspd`（改数据库只 `cp` 文件，不需要停）。
2. **不月虹刷新**（不跑 `yhyc --reload`）。
3. **不软重启、不重启 zygote** —— 第 ③ 步重启 SystemUI 就够。
4. **重启 SystemUI 已获长期授权**，可直接执行；其他任何重启仍须先征得同意。
5. 改数据库前**必须先备份** `modules_config.db.bak`。

#### 验证

```bash
# 路径一致性：两者必须完全相等
dsh-native shell --reason "校验数据库apk_path与新安装路径一致" -- \
  "pm path <模块包名>"
# 再 logcat 看模块自己打的功能日志（不要看版本号字符串）
```

> ⚠️ 版本号不变 ≠ 没生效，代码里常写死版本字符串；判断依据是**功能日志**。

---

### 🎯 DEX 启用方案（2026-10-17 实测定稿，小鹏任务）

> 🔴 **已被上方 2026-10-28 定稿取代。**
> 本节保留作为**历史记录**，其「`cp` 覆盖 + 重启作用域 App」的结论
> **在 lspd dex 缓存面前不成立**。
> 仅在「上方三步方案不可行」时才考虑，且必须知道它可能无效。


> **完整文档：[`/root/xpeng/docs/18-DEX启用方案.md`](/root/xpeng/docs/18-DEX启用方案.md)**
> **这是最终结论，取代此前所有关于「换包名 / 重装 / 清缓存」的旧说法。**

**根因（唯一）**：LSPosed 读 `modules_config.db` 的 `apk_path`，用 ClassLoader
直接打开该路径的 APK。`apk_path` **首次收录后永不自动更新**，
而 `pm install` 每次都会分配**新 codePath** → 指向失效 → 一直加载旧 DEX。

**解法 A —— 首选：不换路径，直接覆盖文件内容**

```bash
# 1) 编译新 APK
cd /root/xpeng/bridge/xpbridge && ./build.sh
# 2) 实查真实路径（必须实查，不要写死）
dsh-native shell --reason "查询模块APK真实路径" -- "pm path com.xpeng.xpextract"
# 3) 覆盖文件内容（路径不变）
dsh-native shell --reason "覆盖更新模块DEX内容" -- \
  "APK=\$(pm path com.xpeng.xpextract | sed 's/package://'); \
   cp -f /sdcard/xpeng/vXX.apk \$APK && chmod 644 \$APK"
# 4) 重启作用域 App —— 唯一必需的生效动作
dsh-native shell --reason "重启小鹏App加载新DEX" -- \
  "for p in \$(ps -A -o PID,NAME | grep xiaopeng | awk '{print \$1}'); do kill -9 \$p; done; \
   sleep 3; content query --uri content://com.xiaopeng.mycarinfo.backgroundLibrary/ >/dev/null 2>&1"
```

**解法 B —— 若已 `pm install` 导致路径变了：同步数据库**

```bash
# 导出库 → 改 apk_path 为新路径 → 写回 → 重启 App（全程不停 lspd）
dsh-native shell --reason "导出LSPosed模块数据库" -- \
  "cp -f /data/adb/lspd/config/modules_config.db /sdcard/xpeng/lsp_now.db; chmod 644 /sdcard/xpeng/lsp_now.db"
# 容器内 python3 改 UPDATE modules SET apk_path=<pm path 的真实值> WHERE module_pkg_name='...'
dsh-native shell --reason "写回修正后的模块路径并重启App" -- \
  "cp -f /sdcard/xpeng/lsp_fix.db /data/adb/lspd/config/modules_config.db && \
   chmod 600 /data/adb/lspd/config/modules_config.db"
```

> ✅ **这两条都不停 lspd、不重启 zygote、不软重启。**
> ⚠️ **修改 `apk_path` 是本方案的必要手段，与「不许停 lspd」不冲突** ——
> 只 `cp` 一个数据库文件，**绝不执行 `lspctl stop` / `kill lspd`**（见下方最高优先级禁令）。

**验证（路径一致性，最直接）**：`pm path <包名>` 的输出必须与
`modules.apk_path` **完全一致**；再用 `logcat | grep -E 'HOOKALL|CMD'` 看新代码的日志。

**🚫 一律不要做的事（实测无效或有害）**：

| 做法 | 结果 |
|---|---|
| 清 `oat` / `/data/dalvik-cache` | ❌ 完全无效 |
| 清 `/data/system/package_cache/*` | ❌❌ **搞坏安装**（重装报错），**永不执行** |
| `cmd package compile -m verify -f` | ❌ 无效 |
| 为「路径不更新」去软重启 | ❌ 无效，白折腾 |
| 靠换包名（bridge2/3/4…）迭代 | ⚠️ 能生效但**不可持续**，仅应急 |

**关键反直觉点**：**版本号不变 ≠ 没生效。** 代码里可能写死版本字符串
（如 `v1.6.0-VERIFY`），判断生效要看**功能日志**，不要看版本号。

### ❓ 常见疑问：为什么 dyys（抖音）模块「重启 App 就生效」，小鹏却要重启系统？

> **用户 2026-10-17 提问，已实测解答。结论：不是模块差异，是「更新手法」差异。**

**真相**：

| 你的更新手法 | codePath 会变吗 | 需要的动作 |
|---|---|---|
| **`cp` 覆盖 `base.apk` 文件内容** | ❌ **不变** | **只重启目标 App** ✅ 这才是 dyys 模式 |
| `pm install -r`（签名/包名不变） | 通常不变 | 只重启目标 App |
| `pm install`（换了签名/包名） | ✅ **会变** | 同步 `apk_path` → 重启 App |
| 卸载 + 重装 | ✅ 必变 | 同步 `apk_path` + **手动重新激活** |

**实测对照（本机 `modules_config.db`）**：

| 模块 | 登记路径 vs 实际路径 | 安装时间 |
|---|---|---|
| 抖音 `com.ss.android.ugc.aweme.yyds` | ✅ **完全一致** | 2026-10-10（长期未动） |
| 小鹏 `com.xpeng.xpextract*` | ⚠️ 曾漂移（高频重装所致） | 反复重装 |

**dyys 之所以「重启抖音就好」，是因为它的 codePath 一个月没变过** ——
不是它有什么特殊待遇。

**🔴 最重要的一条**：

> **LSPosed 从来就是「进程级」注入，不是「系统级」。任何模块都不需要重启系统。**

```
LSPosed 在【目标 App 进程启动时】注入 → 用 ClassLoader 读 apk_path 的 APK
触发点只有两个：
  · 想让抖音加载新代码 → am force-stop com.ss.android.ugc.aweme
  · 想让小鹏加载新代码 → am force-stop com.xiaopeng.mycarinfo
```

**为什么会产生「要重启系统」的错觉**：重启系统时所有 App 重建，
**顺带**让 LSPosed 重扫了一遍 `pm install` 后的新路径、刷新了登记表 → 于是生效了。
**它只是「顺带刷新了登记表」**，代价却是丢掉临时 root、断开 proot 会话。
**完全可以用「同步 apk_path + 重启目标 App」替代，30 秒搞定。**

**✅ 像 dyys 一样更新小鹏模块的正确姿势（终极省事版）**：

```bash
# 1) 编译新 APK
cd /root/xpeng/bridge/xpbridge && ./build.sh
# 2) 直接覆盖文件内容 —— 关键：不要 pm install（那才会换路径）
dsh-native shell --reason "覆盖更新模块DEX内容" -- \
  "APK=\$(pm path com.xpeng.xpextract3 | sed 's/package://'); \
   cp -f /sdcard/xpeng/新版本.apk \$APK && chmod 644 \$APK"
# 3) 重启小鹏 App —— 唯一必需的生效动作（= 抖音的「重启抖音」）
dsh-native shell --reason "重启小鹏App加载新DEX" -- \
  "for p in \$(ps -A -o PID,NAME | grep xiaopeng | awk '{print \$1}'); do kill -9 \$p; done; \
   sleep 3; content query --uri content://com.xiaopeng.mycarinfo.backgroundLibrary/ >/dev/null 2>&1"
```

> 💡 **一句话**：**`pm install` 才会换路径，`cp` 覆盖不会。**
> 想「重启 App 就生效」→ 就用 `cp` 覆盖，永远别 `pm install`。

### 🚫 不要手动去停 lspd 进程

**不要随手动 `lspctl stop` / `kill lspd`。**
一旦把 lspd 弄停，LSPosed 会显示「未安装」，需要人工救场（约 10 分钟）。

- 安装完模块，**最多用月虹刷新一次**（`yhyc --reload`）即可；
- 模块的发现由 LSPosed 自己完成；
- **`apk_path` 不对时，按上面「DEX 启用方案」的解法 B 处理** ——
  那是「改数据库文件 + 重启 App」，**不是**停 lspd 那套流程。

**模块能被发现的必要条件**（踩过的坑）：

1. 模块 APK 里要有一个 **Activity** —— Android 会冻结从未启动过的包的组件，
   LSPosed 因此发现不了它。装完先 `am start` 一次该 Activity。
2. `META-INF/xposed/module.prop` **不要写 `staticScope=false`** ——
   那会要求动态作用域授权，导致不自动加载。


## 🔴🔴 最高优先级禁令：任何任务、任何情况，都不允许停 lspd

> **用户 2026-10-16 明确要求：把「不能停 lspd」放进主记忆，任何任务都不允许停 lspd。**

### 绝对禁止

```bash
/data/adb/modules/zygisk_lsposed/lspctl stop    # ❌❌❌ 永不执行
kill <lspd_pid>                                  # ❌❌❌ 永不执行
killall lspd                                     # ❌❌❌ 永不执行
```

**理由（用户实测结论）**：
> **停了 lspd 之后，即使重新启用它也无效，会显示「LSPosed 未安装」。**

需要人工救场（约 10 分钟），代价远大于任何收益。

### 影响范围

- **不限本任务** —— 所有会话、所有任务、所有场景一律适用
- 即使某份文档（如 `KSU-LSPOSED-RECOVERY.md` 第四节）描述了「改数据库要先停 lspd」的流程，
  **也一律不执行** —— 那条流程已被用户否决
- 不允许以「技术需要」「文档这么写」「只有 3 秒」为理由破例

### 若已误停，恢复步骤

```bash
# 1. 立即启动 lspd（不停留）
nohup /data/adb/modules/zygisk_lsposed/lspd >/dev/null 2>&1 &
sleep 8 && pidof lspd

# 2. 此时 System server 会是 not connected，需要软重启
cd /data/adb/modules/YH_YC && ./yhyc --reload
sleep 10
/data/adb/ksu/bin/ksud soft-reboot
```

### 遇到「模块路径不更新」时的正确做法

> ⚠️ 本节结论已于 **2026-10-17** 被实测推翻，**以「🎯 DEX 启用方案」为准**。
> 下面两条是旧说法，**仅在无法改数据库时才降级使用**。

**首选**（见上方「🎯 DEX 启用方案」）：
1. **直接覆盖 APK 文件内容**，路径不变 → 重启作用域 App ✅
2. 若路径已被 `pm install` 换掉 → **改 `apk_path` 指向新路径** → 重启作用域 App ✅
   （**只 `cp` 数据库文件，全程不停 lspd**，与上面的禁令不冲突）

**降级方案**（改库不可行时）：
1. 卸载重装模块（让 LSPosed 自然重扫，但会**变未激活**，需手动激活）
2. 消除对 LSPosed 版本同步的依赖（把逻辑移到模块外部）

---

## 🔴🔴 禁止传 `sandbox_permissions`——它会弹出「允许本次操作使用 danger-full-access 权限」框

> **用户 2026-10-18 明确要求，写进记忆。**
> 排查耗时约 3 小时、三轮误判，结论如下，**切勿再犯**。

### 症状（用户视角）

界面上反复弹出：

```
允许本次操作使用 danger-full-access 权限：<理由>
[拒绝]  [允许一次]
```

**只有「拒绝 / 允许一次」两个按钮，没有「始终允许」**，
所以点多少次「允许一次」都无济于事，下次照样弹。

### 🔴 唯一真因（已实证）

**是模型在调用工具时自己传了 `sandbox_permissions` 参数。**

该参数由 `@deepseek-ai/dsh-sandbox` 处理（`lib/index.js` 第 107–113 行），
只要收到 `sandbox_permissions`，它就构造一条审批请求：

```js
reason: `escalate sandbox to ${mode}: ${justification}`,
displayReason: {
  zh: `允许本次操作使用 ${mode} 权限：${justification}`
}
switch (outcome) {
  case "allowed-once": return mode;   // ← 「允许一次」即此分支
  case "rejected": throw new Error(...)
}
```

且**本会话运行时已明示**（见系统提示）：

> Approval prompts are disabled in this session: actions that require approval
> are rejected automatically — **do not request sandbox escalation
> (do not set `sandbox_permissions`)**.

### ✅ 处理办法（零配置改动）

**调用 bash / 文件工具时，一律不传 `sandbox_permissions`。没有例外。**

- 本机文件策略本就是 `danger-full-access`（沙箱不限制任何操作），
  **根本不需要提权**，传该参数纯属多余，只会触发弹框。
- ⚠️ 触发时**收到的红字警告**（`[sandbox: file access denied under …]`）
  也**不要去传** `sandbox_permissions` 重试 —— 那是策略拒绝，
  应换思路实现，而不是提权。
- 同理**不要传** `justification`（它只在配 `sandbox_permissions` 时才需要）。

### ❌ 排查时走过的弯路（记录以免重蹈）

| 曾经的错误判断 | 实际 |
|---|---|
| 「App 外壳弹的，去 App 设置里关沙箱开关」 | ❌ App 里**没有**这个开关 |
| 「是 `@deepseek-ai/dsh-experimental-auto-review` 插件弹的」 | ❌ 该插件会问，但**不是这个框**；删掉它弹窗依旧 |
| 「`permission/preset` 档位没设对」 | ❌ 会话第 0 条事件就是 `danger-full-access` + `approval: never` |
| 「删 `package.json` 的 bundle 就好」 | ❌ 与弹窗**无关**，白改一轮 |

**教训**：看到弹窗文案，**第一步就应该 `grep` 它的字符串来源**
（`grep -rn '允许本次操作' <dsh包目录>` 一查即中 `dsh-sandbox`），
而不是凭「沙箱设置」的直觉去猜 App 菜单。

> ⚠️ **auto-review 插件（`@deepseek-ai/dsh-experimental-auto-review`）已恢复启用**
> （2026-10-18，用户要求）。它确实会在判定为中风险时弹审批，
> 但那是**它自己的机制**，与本节所述弹框是两回事，**不要混为一谈**。

---

## 🔴 硬性禁令（未获用户明确允许，一律禁止）

1. **禁止任何重启**：所有重启动作（软重启、硬重启、系统级、服务级、App 进程级）
   一律必须先取得用户明确同意。
   - 硬重启：`reboot`、`svc power reboot`、`reboot recovery`、`reboot bootloader`、
     `reboot -p`（关机）、`stop && start`
   - 软重启：`ksud soft-reboot`、KSU 面板软重启、`setprop ctl.restart zygote`
   - 服务重启：`killall com.android.systemui`、模块 `action.sh`
   - App 进程重启：`am force-stop <pkg>`、`kill -9 <pid>`
   ⚠️ 详见上方「🔴🔴 重启纪律」——**旧版「软重启允许」的说法已作废**。
   理由：完整重启会丢失临时 root 授权、打断 proot 会话；软重启虽轻但同样会中断用户现场。
2. **禁止触碰任何系统分区**：`/system`、`/system_ext`、`/vendor`、`/product`、
   `/odm`、`/boot`、`/init_boot`、`/vendor_boot`、`/dtbo`、`/super`、`/metadata`、
   `/data/adb`（模块增删改）一律只读或不动。
   挂载为可写（`mount -o remount,rw`）同样禁止。
3. 除以上两条外，其余操作在合理范围内可自主执行。

需要动到上述任一项时：**先说明要做什么、影响是什么，等用户明确批准再动手。**

## 🔒 OS4Theme 旋转相关铁律（用户 2026-10-20 明确要求）

> **用户原话：「所有的解锁和锁定都是使用系统的值，我们只是打开和关闭这个开关而已」**

- **不读取、不计算、不写入任何方向值**（`user_rotation_inner` / `user_rotation` 等一律不写）
- 模块只做一件事：**打开 / 关闭系统的「屏幕旋转锁定」开关**
  （折叠屏用 `accelerometer_rotation_inner`）
- 锁定后锁在哪个方向，完全由**系统当前值**决定，模块不干预
- 同样的思路适用于 `accelerometer_rotation_outer`（外屏）

```java
// ✅ 正确：只切开关
putInt("accelerometer_rotation_inner", 1);   // 解除锁定
putInt("accelerometer_rotation_inner", 0);   // 恢复锁定

// ❌ 错误：不要写方向值
putInt("user_rotation_inner", 3);
```

原因：`user_rotation_inner` 在自动旋转期间**不反映真实方向**（实测恒为 0），
读它来锁定会把方向锁成竖屏；而写它则等于强行篡改用户/系统的设置。

### ⚠️ 唯一例外：「内屏固定横屏」且联动开关**关闭**时

> 用户 2026-10-20 确认：**开关关时允许写方向值**。

该模式的需求本身就是「展开后强制横屏（摄像头右上角）」，
不写 `user_rotation_inner` 就无法实现，因此明确允许：

| 联动开关 | 是否写方向值 |
|---|---|
| **关** | ✅ 允许（写 `user_rotation_inner` = 3，同时锁定，合上时还原）|
| **开** | ❌ 禁止（只切 `accelerometer_rotation_inner`）|

## 🖥️ 虚拟屏使用纪律（折叠屏）

本机是折叠屏，**有两块物理屏**，实测拓扑：

| Display ID | 物理唯一 ID | 内/外屏 | 分辨率 | 特点 |
|---|---|---|---|---|
| **Display 0** | `local:4639175402683733248` (port 0) | **内屏（大屏）** | 1672×2364 | ON，`canHostTasks: true`，默认屏 |
| **Display 1** | `local:4639175068132267009` (port 1) | **外屏（副屏）** | 1168×1712 | OFF，`FLAG_PRESENTATION`，`canHostTasks: false` |

- 主屏 = **Display 0**；折叠态下 Display 1 为 OFF。
- **虚拟屏 ID 是动态分配的**（通常从 `Display 2` 起），**不可写死**，
  每次用前必须实际查询当前虚拟屏 ID 再操作。

使用规则：

1. **按需开启，用完即关**——虚拟屏会占用资源，不常驻。
2. **需要确认外观/效果/视觉结果时，直接用主屏（Display 0）**，不要为看效果专门开虚拟屏。
3. 只有需要**后台静默跑 UI 自动化**（不干扰用户当前操作）时才开虚拟屏。
4. 开启后**记下 ID**，任务结束立即关闭，并在回复中说明已关闭。
5. 关闭后若报 `display_terminated_by_user`，说明该屏已不存在，**不要重试同一 ID**。

## 🔑 凭证纪律（用户已授权存放 GitHub PAT）

> **用户 2026-10-18 明确授权**：GitHub 满权限 PAT **可以记住、可以给其他任务读取**。

### 存放位置（唯一）

- **明文集中存放于 [`~/.dsh/ACCOUNT.md`](ACCOUNT.md)**，权限已锁 `600`（仅 root 可读）。
- 其他任务 / 会话需要时，**直接读该文件取值**，不要凭记忆复述。

```bash
# 取值示例
grep -o 'github_pat_[A-Za-z0-9_]*' /root/.dsh/ACCOUNT.md | head -1
```

### 仍须遵守

1. **不要复制到本文件以外的持久文件**（`.git-credentials`、`~/.gitconfig`、
   脚本、仓库、备份）——统一从 `ACCOUNT.md` 取。
2. **不要提交进任何 git 仓库**。⚠️ `AbelDuan/DSH` 是「Config backup」仓库，
   推送前**务必确认不含本文件与 `ACCOUNT.md`**。
3. 不要放进 `/sdcard` 下的公开可读目录。
4. 账号信息：`AbelDuan`（uid 32724782），22 个公开仓库，详见 `ACCOUNT.md`。

## 📲 控制手机必须提前发通知（用户 2026-10-30 定调 · 适用于后续所有任务）

> **用户原话**：「后续当你需要控制手机时，需要弹出一个通知，说明要控制手机。
> 这样的话，我就不操控，交给你来操控。」

### 铁律

**只要本任务需要「控制手机」——即要动设备的屏幕、输入、App、进程或系统状态——
在第一次动手之前，必须先发一条常驻通知，把「我要控制手机」这件事讲清楚。**

- 这是**前置动作**，不是事后汇报：**通知先于第一次控制操作发出**。
- 用户看到通知就把手机交给我，**不会再手动操作**；
  所以我也要**避免和用户抢屏幕**，详见「双向交接纪律」。

### 什么算「控制手机」（触发通知）

| 类别 | 具体动作（示例） |
|---|---|
| 屏幕与输入 | `input tap/swipe/text/keyevent`、`a11y tap/click/text/swipe/global`、`display tap/swipe/key` |
| 读屏幕 | `screencap`、`dsh-native display shot`、`a11y tree`、`a11y screenshot` |
| 界面跳转 | `am start`、`dsh-native start_adb_activity`、`a11y global home/back/recents` |
| App 与进程 | `am force-stop`、`pm install/uninstall`、`content query` 改动静默状态 |
| 设备开关 | 音量、亮度、旋转、静音模式、手电、锁屏/解锁、飞行模式 |
| 系统设置 | `settings put/delete`（含息屏超时、锁定时间等） |
| 媒体采集 | 拍照、录音、录屏、TTS 外放 |
| 虚拟屏 | 创建 / 操作 / 关闭虚拟屏 |

> 纯读取类（`dumpsys`、`pm path`、`logcat`、`settings get`、读文件）**不需要**发通知。
> 判断标准：**会不会改变用户能看见或感知到的设备状态**。会 → 必须发。

### 通知怎么发（统一格式）

```bash
# ① 动手前：发常驻通知（--ongoing 常驻，--id 固定便于后续取消）
dsh-native notify "DSH 正在控制手机"   "任务：<一句话任务名>｜我要操作屏幕/App/设置，这期间请勿手动操作，完成会通知你"   --id 901 --ongoing   --reason "控制手机前按用户要求提前通知，告知用户这段时间勿手动操作"

# ② 任务完成 / 已停止控制：取消常驻通知，再发一条结束提醒
dsh-native notify-cancel --id 901   --reason "任务结束，取消控制手机常驻通知"
dsh-native notify "DSH 已交还手机控制权"   "任务：<任务名>｜已完成，手机交还给你"   --id 901   --reason "任务完成，通知用户交还控制权"
```

- **`--id` 固定用 `901`**：同一条通知反复更新，不刷屏；任务结束用它取消或改写。
- 通知文案**必须包含**：① 要控制手机 ② 任务是什么 ③ 这期间请勿手动操作。
- 文案用中文（本机 zh-CN）。
- `--reason` 必填且要写清楚（每次 `dsh-native` 调用都要求）。

### 双向交接纪律（通知发出之后）

1. **通知发出 = 进入控制期**：从这一刻起，尽量**一口气把界面动作做完**，
   不要在中间长时间停住让用户干等。
2. **控制期结束立刻取消通知**（或改写为「已交还控制权」），**不要留常驻通知**。
3. **推断用户可能正在充电/离开**：不起虚拟屏；**用户在场看效果**：直接操作主屏。
4. 中途若发现**用户在手动操作**（界面状态与预期不符、频繁焦点切换），
   **先停手**，发通知或直接在回复里说明，**不要硬抢屏幕**。
5. 「重启纪律」**不因本通知而放宽**：重启仍须**单独征得同意**，
   发了控制通知 ≠ 获得重启授权。

### 与其他规范的关系

| 规范 | 关系 |
|---|---|
| 「🔴🔴 重启纪律」 | **不冲突**。控制通知只解决「抢不抢屏幕」，重启仍要单独批准 |
| 「⏱️ 休眠与锁屏超时规范」 | 改超时前**先发控制通知**，结束后**还原 + 取消通知** |
| 「🔓 解锁规范」 | 解锁属于控制手机 → **先发通知再解锁** |
| 「🖥️ 虚拟屏使用纪律」 | 开关虚拟屏属于控制手机 → **覆盖到通知范围** |
| 「⏳ 命令执行超时纪律」 | 通知调用同样要传 `timeoutMs`，`dsh-native` 用 30000 + `timeout 25s` |

## 🎯 调试纪律：不兜底、不强行归正，先懂原理再正向解决（用户 2026-10-31 定调）

> **用户原话**：「进行开发调试时，尽量少甚至不要使用各种兜底规则，在错误的路上强行归正。
> 我们需要明白原理，正向出发解决对应的问题，达到最优效果。」

### 铁律

**遇到问题时，先把原理搞明白，再从根因正向解决。禁止用兜底、补丁、强行归正去掩盖问题。**

| ✅ 要做的 | ❌ 禁止的 |
|---|---|
| 定位根因（读源码 / 抓数据 / 复现） | 加 `try/catch` 把异常吞掉 |
| 从正确的那一层修复 | 在错误的那层反复打补丁 |
| 让错误自然暴露并修好 | 用 `fallback` / `??` / `||` 掩盖未定义 |
| 理解机制后一次性改对 | 加超时 / 重试 / 扩容器「让它先跑起来」 |
| 改完后用同一套数据复验 | 改到「看起来好了」就收工 |

### 什么算「兜底 / 强行归正」（禁止）

- **吞异常**：空 `catch`、`catch(e){}`、`catch { return null }`
- **默认值掩盖**：用 `??`、`||`、`?.` 把「本该报错的 undefined」变成静默空值
- **假成功**：失败时返回空数组 / 空对象，让上层以为成功
- **盲目重试**：不查为什么失败就 `retry(3)`、`setTimeout` 重连
- **放宽约束**：为了不报错而调大 timeout、加 `|| true`、跳过校验
- **打补丁式规避**：`try A, fail → 再试 B, C, D` 的链式兜底
- **用结果反推调参**：只改数字（间隔、阈值、延时）直到「不报错」

> ⚠️ **注意区分**：**必要的防御**（校验用户输入、处理真实的网络失败）
> 不属于兜底；**兜底**是「明知道某处逻辑不对，却用代码掩盖它」。

### 正向解决的流程（四步，缺一不可）

```text
① 现象：把错误原文、复现步骤、影响范围写清楚（不要凭感觉）
② 原理：这个机制本来应该怎么运作？去读源码 / 文档 / 抓数据验证
③ 根因：哪一层的假设错了？一条证据链锁定它，不猜测
④ 修复：在正确的层改一次，删掉所有为此加的兜底
```

- **强要求**：修复后**回头删掉**之前为了绕过这个问题加的兜底代码。
- **验证**：用**同一套采集/复现手段**确认数值或行为已变好，
  不是「看起来对了」。
- **拿不准原理时**：先停下来查证，**不要一边猜一边加兜底**。

### 与「不重启」等铁律的关系

「优先选择不需要重启的方案」**不是**叫你去加兜底绕过重启；
而是要求**先弄明白机制**，找到真正需要重启的那个最小范围。
（例：LSPosed 模块更新 → 搞清 `apk_path` + dex 缓存原理
→ 得出 `pm install -r` + 同步路径 + 重启 SystemUI 的正向方案。）

### 交付时自检

任务结束前回答三个问题：

1. **我加的每一行代码，是根因修复还是兜底？**
2. **之前为绕过此问题加的兜底，删干净了吗？**
3. **我能一句话讲清楚这个问题的原理吗？** 讲不清 = 没真懂，回去查。

## ⏳ 命令执行超时纪律（最高优先级 · 用户 2026-10-17 要求）

> **用户原话**：「关于执行脚本的等待时间，你的等待时间太长了，超时时间太长了，
> 每次都卡在那儿，我给你的新的输入也无法执行。」

### 核心问题

调用 bash/脚本时**不显式指定超时**，就会走 executor 的长默认值。
命令一旦挂住（等待输入、等网络、死循环、等设备响应），
**整个会话被占住，用户在界面上发的新消息只能排队等** —— 这是不可接受的。

### 🔴 铁律

1. **每次调用 bash 必须显式传 `timeoutMs`**，不允许依赖默认值。
2. **任何可能挂住的命令，在 shell 层再加一层保险**：`timeout 20s <cmd>`。
   工具超时 + shell 超时**双保险**，缺一不可。
3. **长任务必须后台**：预计超过 60 秒的任务，一律 `run_in_background: true`，
   用 `job_output` **非阻塞**查看；**没有真正阻塞的必要，绝不传 `wait: true`**。
4. **命令超时被移到后台后，不要反复 `wait`** —— 先响应用户的新消息，
   再回头用 `job_output` 收结果。卡住的 job 直接 `job_kill`。

### 超时档位对照表（默认按此执行）

| 命令类型 | 示例 | `timeoutMs` | shell 层保险 |
|---|---|---|---|
| 瞬时查询 | `ls` / `cat` / `grep` / `pm path` / `settings get` | **10000** | `timeout 5s` |
| 常规命令 | `cp` / `mkdir` / `sqlite3` / 普通 shell 逻辑 | **20000** | `timeout 15s` |
| 设备/root 调用 | `dsh-native shell` / `am` / `pm` / `killall` | **30000** | `timeout 25s` |
| 编译构建 | `./build.sh` / `gradle` / `aapt` | **120000**（并**后台跑**） | 后台 + `timeout 110s` |
| 长时守护 | 日志监听 / 轮询 / 大批量拷贝 | **必须后台** | 后台任务 + 必要时 `job_kill` |

### 交互式命令的额外禁令

- **禁止执行会等待标准输入的命令**（`ssh` 无 `-o BatchMode=yes`、
  `gh auth login` 非交互式、`read` 等），一律加非交互标志或走后台。
- `ssh` 必须带：`-o BatchMode=yes -o ConnectTimeout=5`。
- `curl`/`wget` 必须带：`--max-time 10 --connect-timeout 5`。

### 后台任务的收尾纪律（交付前必做）

```bash
# 干完活之前，逐个收尾：该收的收，该杀的杀
```

- 每个启动过的后台 job id **都要有交代**：结果相关 → `job_output` 收集；
  已无意义 → `job_kill` 显式终止。
- **不允许留下仍在跑的后台任务**而无说明。

## ⏱️ 休眠与锁屏超时规范（执行任务时）

### 🔴 铁律：改过的设置，任务结束必须逐个还原

用户明确要求（2026-10-16）：

> **对本设备做的所有「屏幕超时」和「自动锁屏时间」调整，
> 都必须在任务结束后恢复之前设置的状态。**
> **本机原始状态 = 一分钟无操作锁屏。**

### 需要管控的两个设置项

| 设置项 | 位置 | 含义 | **本机原始值** |
|---|---|---|---|
| `screen_off_timeout` | `system` | 无操作多少毫秒后**息屏**（息屏即锁屏） | **60000**（1 分钟） |
| `lock_screen_lock_after_timeout` | `secure` | 按电源键后**延迟多久自动锁屏** | **null**（系统默认） |
| `stay_on_while_plugged_in` | `global` | 插电时是否常亮 | **0**（关） |

> ⚠️ 这两个都是**用户可见设置**，改动属**临时借用**，不是永久配置。
> **本机基准 = 60 秒无操作锁屏**，任务结束一律以此为准还原。

### 标准化操作流程（延长 → 干活 → 还原）

```bash
# ── Step 0：先记录原值（任何改动之前！）
dsh-native shell --reason "记录修改前的息屏与锁屏超时原值以便任务后还原" \
  -- "settings get system screen_off_timeout; settings get secure lock_screen_lock_after_timeout"

# ── Step 1：延长超时（仅当任务需要连续操作时）
dsh-native shell --reason "执行多步UI任务期间临时延长息屏超时避免中途黑屏" \
  -- "settings put system screen_off_timeout 600000"

# ── Step 2：执行任务 ……

# ── Step 3：还原（任务结束必须做，不可省）
dsh-native shell --reason "任务结束按用户要求还原息屏超时为原始的一分钟" \
  -- "settings put system screen_off_timeout 60000"
# 若 lock_screen_lock_after_timeout 也被改过，一并还原其原值（本机为 null → 删除该项）
dsh-native shell --reason "还原自动锁屏时间为系统默认" \
  -- "settings delete secure lock_screen_lock_after_timeout"
```

### 建议超时对照

| 场景 | 动作 |
|---|---|
| 单步快操作（< 30 秒） | **不改**，直接做 |
| 多步 UI 自动化 / 截图定位 | 延长到 **600000ms（10 分钟）** |
| 长时间守护型任务 | 延长到 **1800000ms（30 分钟）** |
| **任务结束** | **无条件还原为 60000（1 分钟）** |

### 还原自检（交付前必做）

```bash
# 确认已回到用户基准值
dsh-native shell --reason "交付前自检息屏超时是否已还原为用户的原始设置" \
  -- "settings get system screen_off_timeout"
# 必须输出 60000；否则视为任务未完成
```

> ⚠️ `caps.settings` = `no_write_settings`（未授权），
> 必须经 `dsh-native shell`（root 通道）写入，**不走** `dsh-native settings`。
> 还原后需在回复中**明确说明改过哪些设置、是否已还原**。

## 🔓 解锁规范（锁屏时）

**解锁方式：唤醒屏幕 → 识别屏幕 → 依次点击 `080808`。**

### ⚠️ 核心约束：屏幕熄得极快（60 秒）

**要么一口气做完，要么全程保持唤醒。** 半路黑屏会让点击落空、截图全黑。

```bash
# 方案 A（推荐）：先延长超时，再从容操作
dsh-native shell --reason "解锁前延长息屏超时避免中途黑屏" \
  -- "settings put system screen_off_timeout 600000"
# → 唤醒 → 截图识别 → 输入 080808 → 还原超时

# 方案 B：不改成全局设置，操作中间穿插唤醒保活
dsh-native shell --reason "保持屏幕唤醒以便连续完成解锁点击" \
  -- "input keyevent KEYCODE_WAKEUP"
```

### 标准解锁流程

1. **判断是否锁屏**：`dumpsys window | grep -E 'mDreamingLockscreen|mShowingLockscreen'`
   - `mDreamingLockscreen=true` → 已锁屏，需解锁
   - 两者均 `false` → **未锁屏，直接操作即可**
2. **唤醒屏幕**（若 `mWakefulness` 为 `Dozing`/`Asleep`）：
   `input keyevent KEYCODE_WAKEUP`
3. **截图识别**：确认锁屏界面（**注意浮窗遮挡**，见下）
4. **点击 `080808`**：
   ```bash
   # 数字键盘可直接文本输入
   dsh-native shell --reason "输入解锁密码完成解锁" -- "input text 080808"
   # 若需按位点击，则逐位 tap 并按实际截图坐标定位
   ```
5. **验证解锁结果**：再次截图 + 查 `mDreamingLockscreen` 确认已进桌面

### 解锁时的已知陷阱

| 陷阱 | 应对 |
|---|---|
| **60 秒自动熄屏** | 先延长超时，或每步穿插 `KEYCODE_WAKEUP` |
| **`screencap` 全黑** | 屏幕处于 Dozing，先唤醒再截 |
| **DSH 浮窗遮挡** | 浮窗盖住锁屏界面，截到的是浮窗而非锁屏；先确认或收起浮窗 |
| **点击落空** | `input tap` 在息屏态下静默失败，不报错 |
| **显示 ID 变化** | 折叠屏 Display ID 会重新分配，操作前用 `dumpsys SurfaceFlinger --display-id` 实查 |


---

## 🔴 界面跳变（左右/上下横跳）的唯一真因：App 外壳的挖孔避让注入

> **2026-10-19 定稿。排查耗时极长，走过大量弯路，结论如下，切勿再从插件/键盘方向找。**

### 症状

横屏下界面内容（会话区、侧边栏）会**「右下左上」跳一次**，或**左右横跳**、**上下跳一下**。

### 真因（已用数据钉死）

**不是 DSH、不是任何插件、不是键盘、不是输入法** —— 是 **DSH-Folk App 外壳**注入的：

```html
<style id="__dsh_folk_insets__">   ← App 原生代码注入，DSH 与插件都碰不到
  #root { box-sizing: border-box !important; padding: 65px 65px 20px 0px !important; }
```

它按**「上右下左」**反复改写 `#root` 的 padding：

| padding（上右下左） | 效果 |
|---|---|
| `0px` | 正常 |
| `65px 0 0` | 下移 65 |
| `65px 0 20px` | 下移 65、上移 20 |
| **`65px 65px 0 0`** | **下移 65、左移 65** ← 摄像头在右 |
| **`65px 65px 20px 0`** | **下移 65、左移 65、上移 20** |

`#root` 是 `border-box`，**宽度恒为 1096 不变**，padding 从内部吃掉空间 → 内容列在 **816px ↔ 751px** 之间跳（实测 `cw` 1096 ↔ 1031）。

### 关键判据（一眼确认是不是它）

```bash
# 1) 看注入者是不是 App 外壳（而不是插件）
grep -rn '__dsh_folk_insets__' <dsh目录> <插件目录>   # 搜不到 → 是 App 原生注入
```

- **摄像头转到左下** → 界面「**往上右**」跳
- **摄像头转到右上** → 界面「**往右下**」跳
- 与 `dumpsys window displays` 的 `ROTATION_90 左126px / ROTATION_270 右126px` 完全吻合

### 修复（在插件里覆盖，特异性必须 ≥ 外壳）

```css
/* ⚠ 必须用 html body 前缀把特异性抬到 (1,0,2)，压过外壳的 (1,0,0)，
      否则谁后注入谁赢，结果不稳定 */
html body #root{padding-left:0 !important;padding-right:0 !important}
html body #root{padding-bottom:20px !important}
html body #root{padding-top:max(65px,env(safe-area-inset-top,0px)) !important}
```

- **左右清零**：用户明确「不需要页面避让摄像头」
- **底部钉 20px**：否则底栏开合时图标上下跳（实测 `ih=775→750` 时 padding-bottom `20→0`）
- **顶部钉住**：外壳 insets 是**异步**算的，首帧还没算完 → 会话页刚打开会压状态栏，唤出输入法（触发 resize）后才正常。插件主动补上即可

### ❌ 排查时走过的弯路（记录以免重蹈）

| 曾经的错误方向 | 实际 |
|---|---|
| 怪 `dsh-sidebar-tweaks` 插件 | ❌ A/B 停用后**照样跳** |
| 怪 `dsh-web-mobile` | ❌ 停用后**照样跳** |
| 怪键盘高度变化（`ih` 775→445） | ❌ 悬浮键盘也跳；实测 `kb=0` 时也跳 |
| 怪输入法（微信输入法工具栏） | ❌ 换成小米输入法照样跳 |
| 怪视口跨 1024 阈值 | ❌ 实测 `iw` 恒为 1096，从未跨过 |
| 加 `maximum-scale=1` | ⚠️ 治标，且引入新问题，后已移除 |
| 加 `overflow-x:hidden` | ⚠️ 无效（横向本来就没溢出） |
| 全量禁动画 | ⚠️ 无效（不是动画问题） |

### 🎯 排查这类问题的正确顺序（血泪教训）

1. **先做 A/B 隔离**（停用插件看现象是否消失），**不要先改代码**
2. **拿到运行时数据**：容器内起 HTTP 收集服务 + 插件上报（见下方「数据采集链路」）
3. **沿 DOM 祖先链逐层测宽度**，找出**第一个变化的元素**
4. **扫 `document.styleSheets` 找命中该元素的规则**，读 `ownerNode.id` 指认注入者
5. 确认根因后再改，改完**用同一套采集复验**（数值不变才算修好）

### 📡 数据采集链路（容器连不上 WebView CDP 时的唯一出路）

本机 **`/proc/net/unix` 没有 `webview_devtools_remote`**（调试未开），**logcat 也不收 WebView console**，
容器内**无 ffmpeg / PIL / numpy**（apt 因 proot 拿不到 dpkg 锁装不上）。

**可行的替代方案** —— 容器内起服务，让页面主动上报：

```bash
# 容器内（脱离进程组，避免被后续操作带走）
cd /tmp && cat > collector.js <<'EOF'
const http=require('http'),fs=require('fs');
http.createServer((q,r)=>{fs.appendFileSync('/tmp/kb_events.log',
  new Date().toISOString()+' '+q.url+'\n');
  r.writeHead(200,{'access-control-allow-origin':'*'});r.end('ok');}).listen(3099,'0.0.0.0');
EOF
setsid nohup node collector.js >/tmp/collector.out 2>&1 </dev/null &
```

插件侧用 `new Image().src = 'http://127.0.0.1:3099/log?...'` 上报（**只在数值变化时发**，避免刷屏）。

> ⚠️ App 能访问 `127.0.0.1:3080`（DSH 自身），说明**容器端口对 WebView 可见**。

### 合并插件：`dsh-mobile-tweaks`

原 `dsh-sidebar-tweaks` + `dsh-ime-submit-guard` 已合并为 **`dsh-mobile-tweaks`**
（`dsh-web-mobile` 按用户选择保持独立）。

**合并必须用 IIFE 隔离** —— 两个原插件有 **7 个同名顶层标识符**
（`NAME / SCAN_INTERVAL_MS / apply / doc / safe / start / state`），
其中 `start`/`state`/`apply` 实现完全不同，直接拼接会**静默覆盖、功能失效**。

```js
var PART_A = (function () { /* 侧边栏 */ return {...}; })();
var PART_B = (function () { /* 输入法 */ return {...}; })();
function apply(ctx) {
  try { PART_A.apply(ctx); } catch (e) {}
  try { PART_B.apply(ctx); } catch (e) {}   // 互不牵连
}
```

## 📦 dsh-mobile-tweaks 插件结构（2026-10-22 定稿 · 永久免疫）

> **用户 2026-10-22 明确要求：这个插件不能被任何其他东西影响，除非他手动卸载或手动调整。**

| 角色 | 路径 |
|---|---|
| **真身（唯一源）** | `/root/.dsh/plugins/dsh-mobile-tweaks/` |
| 主入口（installAnchor 第一优先） | `/usr/local/lib/node_modules/dsh-mobile-tweaks` → 真身 |
| 备入口（rootfs 重写也保留） | `/root/.node_modules/dsh-mobile-tweaks` → 真身 |
| **Loader 解析入口（ESM 上溯，最关键）** | `/root/.dsh/node_modules/dsh-mobile-tweaks` → 真身 |
| 自愈脚本 | `sh /root/.dsh/plugins/fix-mobile-tweaks.sh` |
| 完整说明 | `/root/.dsh/plugins/README-mobile-tweaks.md` |

**两条链路都要通，缺一条就静默失效**（2026-10-22 两次踩坑的教训）：

1. **bundle 解析**：`installAnchor` 的 Node 查找路径（`/usr/local/lib/node_modules`、`/root/.node_modules`）。
2. **Loader import**：cordis Loader 以 **profile 目录**为 baseUrl 做 ESM 解析，
   会沿 `node_modules` 向上找 → 必须命中 `/root/.dsh/node_modules/dsh-mobile-tweaks`。
   缺这条时报 `ERR_MODULE_NOT_FOUND`，**可能什么都不打印**。

**三条铁律**：

1. **`profiles/web/package.json` 的 `dependencies` 里绝不能出现 `dsh-mobile-tweaks`**
   —— 出现即被 pnpm 接管，重跑可能改成自引用软链（2026-10-22 失效真因）；
   `dsh.profile.bundles` 里的名字必须保留。
2. **不要往 `profiles/web/node_modules/` 放这个包**（pnpm 会删改）。
3. **改插件代码只改真身** → 重启 folk App 即生效（无需 pnpm / 软重启）。
   注意 `lib/index.js` 必须是 `export const name = 'dsh-mobile-tweaks';`（**带引号**）——
   2026-10-22 就是这里丢了引号，导致整条链路静默失败、重启也不生效。

**失效排查顺序**：先 `sh /root/.dsh/plugins/fix-mobile-tweaks.sh`
（检查真身、重建三条软链、验证 bundle 解析 + 宿主 import），再重启 App。

## 🔓 核心破解：应用可跨签名覆盖安装（用户 2026-10-28 告知）

> **用户原话：「设备有核心破解，应用可以覆盖安装」**

### 含义

本机已具备**核心破解（Core Patch）**能力 —— 系统层的 APK 签名校验被绕过，
因此**不同签名的 APK 也可以覆盖安装**到同一个包名下。

### 对操作的影响

| 场景 | 常规设备 | **本机** |
|---|---|---|
| 同签名覆盖安装 | ✅ 可以 | ✅ 可以 |
| **不同签名覆盖安装** | ❌ `INSTALL_FAILED_UPDATE_INCOMPATIBLE` | ✅ **可以** |
| 降级安装 | 需 `-d` | 一般可直接 `-d` |
| 修改系统应用 | 需 root 手工替换 | 可走覆盖安装路径 |

**实际收益**：

1. 不必先 `pm uninstall` 再装 —— 直接覆盖，**保住应用数据**。
2. 自己重新编译签名的 APK，可以盖到官方版本上（换签名不再是障碍）。
3. 模块 APK 更新时可走覆盖安装，但 **⚠️ 仍优先用 `cp` 覆盖 `base.apk` 文件内容**
   （见「🎯 DEX 启用方案」——`cp` 不换 codePath，`pm install` 会换）。

### 使用注意

- **优先 `cp` 覆盖文件内容**，仍然是最短路径（不换路径、不触发 LSPosed 的 `apk_path` 漂移）。
- 只有在需要走 PackageManager 正式登记时才用 `pm install -r`。
- 覆盖安装**不改变**「重启纪律」：装完是否需要重启目标 App / SystemUI，仍按既有规则办。
- 覆盖安装**不改变**「禁止触碰系统分区」的禁令。

## 📁 共享存储目录规范（用户 2026-10-30 强调 · 唯一工作根目录，最高优先级）

> **用户原话（2026-10-30，收紧后）**：
> 「**1. 不允许在别的目录乱放文件，尤其是根目录**，你配置的环境，依赖，截图，录视频，
> 日志，源码，编译等等**都放在 `/storage/emulated/0/Documents/DSH/`**，
> 在这里你可以任意创建编辑删除等动作，你可以**完全权限管理**。
> 2. 你创建的任何模块等，都要有**保留配置文件迭代 / 备份恢复配置**的能力，
> 不要一更新配置就掉了。」

**唯一工作根目录：`/storage/emulated/0/Documents/DSH/`（等价 `/sdcard/Documents/DSH/`）**

### 🔴 铁律一：一切落盘都进这里，尤其不许在根目录乱放

| 类型 | 落点 |
|---|---|
| 环境 / 依赖（SDK、NDK、JDK、venv、node_modules、工具链） | `envs/<项目>/` |
| 截图 / 录屏 / 抓取素材 | `artifacts/<项目>/` 或 `logs/<项目>/` |
| 日志、调试输出、抓包 | `logs/<项目>/` |
| 源码、脚本、方案文档 | `projects/<项目>/` |
| 编译产物、APK/DEX/内核/固件 | `builds/<项目>/` |
| 配置备份、回滚点、快照 | `backups/<项目>/` |
| 临时中转（可随时清空） | `tmp/<项目>/` |

- **禁止**：在 `/`、`/root`、`/tmp`、`/usr/local`、`/sdcard` 根、`Download/` 等
  位置**新建**任何项目文件、目录、截图、日志、源码、构建产物。
- **禁止**：把 `/root/xxx` 之类「随便挑个目录」当项目目录。
  历史遗留目录（`/root/xpeng`、`/root/OS4Theme` 等）**只读参考，不再往里写新东西**。
- `/root/.dsh/`（DSH 自身配置目录）属于**框架自身**，不算「乱放」，
  但**只放配置与记忆文件**，不放项目源码 / 构建产物 / 截图。
- **铁律依据**：该目录用户已明确授予**完全读写删权限**，是唯一被授权的自由区。

### 固定七类与结构（不要新增顶层类别）

| 目录 | 放什么 |
|---|---|
| `builds/` | 构建输出：APK / DEX / 内核 / 固件 / 打包产物 |
| `projects/` | 项目工作区：源码 / 脚本 / 文档 / 依赖清单 |
| `envs/` | 环境与工具链：SDK / NDK / JDK / venv / node_modules |
| `artifacts/` | 交付物与发布包 / 截图 / 录屏：最终 zip / 签名件 / 分发物 |
| `logs/` | 运行日志、抓取日志、调试输出 |
| `backups/` | 配置备份 / 快照 / 回滚点（见铁律二） |
| `tmp/` | 临时中转，可随时清空 |

### 命名规范

- 二级 = **项目名**（小写连字符）：`builds/xpeng/`、`projects/o3cpuset/`
- 三级 = 版本或日期：`v1.6.0/`、`20261028/`
- 完整示例：`builds/xpeng/v1.6.0/xpextract.apk`

### 执行要求

1. **新项目第一次落盘时，主动建 `项目名` 子目录**，不要平铺在类别根下。
2. 动手写文件前先 `mkdir -p` 建好完整路径，**默认就在 `DSH/` 下**，
   除非用户明确指定了其它位置。
3. `tmp/` 不做长期存放；`logs/` 需定期清理；`backups/` 只增不删。
4. 历史遗留路径（`/sdcard/xpeng/`、`/root/xpeng` 等）**不强制迁移**，但**新产出走新规范**。

### ⚠️ 共享存储的技术限制（这是唯一需要绕开的地方）

| 限制 | 后果 | 应对 |
|---|---|---|
| 无硬链接 | `link()` 报 EINVAL | 不用 `ln` |
| **无软链接** | 符号链接不被支持 | 不用 `ln -s` |
| 无执行位 | 脚本不能 `./run.sh` | 用 `sh run.sh` |
| `write` 工具原子发布会失败 | 报悬空软链 / EINVAL | 用 shell 重定向或 `edit` |

**在 `DSH/` 下新建文件：用 shell 重定向或 `edit` 工具，不要用 `write`。**

```bash
cat > /storage/emulated/0/Documents/DSH/projects/foo/README.md <<'EOF'
内容
EOF
```

> ⚠️ heredoc 里**不要出现反引号**（如 `` `write` ``）——会被 shell 当命令替换，
> 报 `unexpected EOF while looking for matching`。需要写反引号时，
> 先在容器内 `DSH/tmp/` 下生成，再 `cp` 过去（`cp` 不依赖链接，可用）。

**确实需要硬链接 / 软链 / 执行位的东西**（git 仓库、`node_modules`、编译中间件）：
**例外允许放在 `/storage/emulated/0/Documents/DSH/envs/<项目>/work/`** 之外的
容器内临时目录 `/tmp/dsh-work/<项目>/`（**仅限 `/tmp`，不许进 `/root`**），
产物拷回 `builds/` 或 `artifacts/`。**除 `/tmp/dsh-work/` 外没有任何容器内工作目录例外。**

### 🔑 敏感凭证的例外

凭证**不放进 `DSH/`**（那是 `/sdcard` 公开可读区）：
只放 `~/.dsh/ACCOUNT.md`（权限 600）。这是本节唯一的例外。

## ☁️ GitHub 配置同步（2026-10-23 起改用 API 脚本）

**官方「同步」的 git 通道在本机不可用，两个独立原因：**

1. **本地 git 对象库写不进去** —— folk 用 l2s 模拟硬链接（`PROOT_L2S_DIR`），
   git 发布对象时用的 `link()` 被转成**悬空软链**（`.git/objects` 里 0 个真实文件、
   一堆指向不存在目标的软链）。任何仓库（包括最小复现 `git init + add + commit`）
   都报 `... is not a valid object`。之前远端的对象缺失也是这个原因造成的。
2. **直连 github.com 不通**（`git push` 超时），只能经 `gh-proxy.org` 公共代理；
   **不应把 PAT 交给第三方代理**。

**现在的同步方式（安全、可靠）：**

```bash
# 1) 在 DSH 里执行一次配置备份，生成 ZIP 到 ~/.dsh/dsh-config-manager/exports/
# 2) 推送（默认取最新 ZIP；也可显式传路径）
python3 /root/.dsh/plugins/dsh-github-sync.py
# 3) 归档一份到本地 DSH 备份区（铁律二：备份只增不删）
cp -f ~/.dsh/dsh-config-manager/exports/*.zip \
  /storage/emulated/0/Documents/DSH/backups/dsh-config/ 2>/dev/null || true
```

- 目标：`AbelDuan/DSH` 的 `backups/` 目录；每次新增一个提交（parent 保留历史）
- 恢复：下载 ZIP → DSH「配置 → 导入」
- token 从 `~/.dsh/ACCOUNT.md` 实时读取，不落盘到其它文件
- **本地备份副本统一放 `backups/dsh-config/`**，与远端是双保险

**遗留物：**
- `~/.dsh/dsh-config-manager/sync/work` 的对象库已重定向到
  `/root/workspace/sdcard/.dsh-sync-gitobj`（跨设备绕开 l2s，本地 git 可用）；
  但推送仍受网络限制，该 git 通道不再使用。
- 远端旧的 `snapshots/sync-*` 历史未改动，`backups/` 是新增目录。

> ⚠️ 该 gitobj 目录是**历史遗留**，位于 `/sdcard` 根下。
> 按 2026-10-30 铁律**不再往那里写新东西**；新产出统一走 `Documents/DSH/`。

**⚠️ 写文件注意**：l2s 下 `write` 工具的「临时文件 + rename」原子发布也会变成悬空软链
（新文件报 dangling symlink）。在容器内**新建文件请用 shell 重定向**
（`cat > f <<'EOF'`）或 `edit` 工具。
